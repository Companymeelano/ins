import crypto from 'crypto';
import { db } from '@/db';
import { panelUsers, sessions } from '@/db/schema';
import { eq } from 'drizzle-orm';

// هش پسورد با scrypt
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':');
    const test = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(test, 'hex'));
  } catch {
    return false;
  }
}

// اطمینان از وجود کاربر admin پیش‌فرض (admin/admin) — idempotent و ضد race condition
export async function ensureAdmin() {
  await db.insert(panelUsers).values({
    username: 'admin',
    passwordHash: hashPassword('admin'),
    role: 'admin',
    displayName: 'مدیر سیستم',
  }).onConflictDoNothing({ target: panelUsers.username });
}

export function newToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export async function createSession(userId: number): Promise<string> {
  const token = newToken();
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 7); // ۷ روز
  await db.insert(sessions).values({ token, userId, expiresAt });
  return token;
}

export async function getUserByToken(token: string) {
  if (!token) return null;
  const [s] = await db.select().from(sessions).where(eq(sessions.token, token));
  if (!s || (s.expiresAt && new Date(s.expiresAt) < new Date())) return null;
  const [u] = await db.select().from(panelUsers).where(eq(panelUsers.id, s.userId!));
  return u || null;
}

export async function destroySession(token: string) {
  await db.delete(sessions).where(eq(sessions.token, token));
}
